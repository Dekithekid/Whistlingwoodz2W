package com.example.whistlingwoodz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
